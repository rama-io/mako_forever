package com.rama.mako_zero.managers;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.rama.mako_zero.R;
import com.rama.mako_zero.objects.Themes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ThemeManager {

    private ThemeManager() {
    }

    public static Themes.Palette paletteFor(String themeId) {
        return Themes.byId(themeId);
    }

    public static Themes.Palette currentPalette(Context context) {
        return paletteFor(PrefsManager.getInstance(context).getTheme());
    }

    public static void applyTheme(Context context, View root) {
        Themes.Palette palette = currentPalette(context);
        Map<Integer, Integer> colorMap = buildColorMap(context, palette);
        applyRecursively(root, palette, colorMap);
    }

    private static void applyRecursively(View view, Themes.Palette palette, Map<Integer, Integer> map) {
        applyToView(view, palette, map);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyRecursively(group.getChildAt(i), palette, map);
            }
        }
    }

    private static void applyToView(View view, Themes.Palette palette, Map<Integer, Integer> map) {

        if (view instanceof AbsListView) {
            // The old Theme.Black-family default listSelector is an orange
            // glow baked into the platform theme - overriding it here is the
            // only way to actually replace it (a colors.xml entry can't reach
            // it, since AbsListView draws it itself, not as a themed attr).
            // A StateListDrawable still reacts to state_focused, so dpad/
            // keyboard navigation keeps a visible highlight.
            ((AbsListView) view).setSelector(buildSelector(palette));
        }

        if (view instanceof TextView) {
            TextView textView = (TextView) view;

            if (view instanceof RadioButton || view instanceof CheckBox) {
                textView.setTextColor(palette.text);
            } else {
                Integer mapped = map.get(textView.getCurrentTextColor());

                if (mapped != null) {
                    textView.setTextColor(mapped);
                }
            }
        }

        if (view instanceof ImageView) {
            ((ImageView) view).setColorFilter(palette.text, PorterDuff.Mode.SRC_IN);
        }

        Drawable background = view.getBackground();

        if (background instanceof ColorDrawable) {
            int color = getColorDrawableColor((ColorDrawable) background);
            Integer mapped = map.get(color);

            if (mapped != null) {
                view.setBackgroundColor(mapped);
            }
        } else if (background != null) {
            background.mutate().setColorFilter(palette.text, PorterDuff.Mode.SRC_IN);
        }
    }

    /**
     * Pressed/focused = a translucent tint of the theme's accent color;
     * everything else transparent, so rows show their normal background.
     */
    private static Drawable buildSelector(Themes.Palette palette) {
        int highlight = withAlpha(palette.accent, 110);

        StateListDrawable selector = new StateListDrawable();
        selector.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(highlight));

        if (android.os.Build.VERSION.SDK_INT >= 14) {
            // AbsListView's per-row state_focused tracking is unreliable on
            // Gingerbread (API 9/10) and earlier - it can end up true for
            // every row instead of just the one with input focus, lighting
            // up the whole list permanently. Below API 14, dpad/keyboard
            // users fall back to press-only feedback instead of that.
            selector.addState(new int[]{android.R.attr.state_focused}, new ColorDrawable(highlight));
        }

        selector.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return selector;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    @SuppressWarnings("deprecation")
    private static int getColorDrawableColor(ColorDrawable drawable) {
        try {
            return (Integer) ColorDrawable.class.getMethod("getColor").invoke(drawable);
        } catch (Exception e) {
            return Integer.MIN_VALUE;
        }
    }

    private static Map<Integer, Integer> buildColorMap(Context context, Themes.Palette target) {
        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
        List<Themes.Palette> all = Themes.all();

        for (int i = 0; i < all.size(); i++) {
            Themes.Palette p = all.get(i);
            map.put(p.text, target.text);
            map.put(p.base, target.base);
            map.put(p.surface_0, target.surface_0);
            map.put(p.surface_1, target.surface_1);
            map.put(p.subtle, target.subtle);
            map.put(p.disabled, target.disabled);
            map.put(p.border, target.border);
            map.put(p.accent, target.accent);
            map.put(p.accent_2, target.accent_2);
            map.put(p.accent_3, target.accent_3);
            map.put(p.accent_4, target.accent_4);
            map.put(p.accent_5, target.accent_5);
            map.put(p.success, target.success);
            map.put(p.warning, target.warning);
            map.put(p.error, target.error);
            map.put(p.info, target.info);
            map.put(p.link, target.link);
        }

        android.content.res.Resources res = context.getResources();
        map.put(res.getColor(R.color.text), target.text);
        map.put(res.getColor(R.color.base), target.base);
        map.put(res.getColor(R.color.surface_0), target.surface_0);
        map.put(res.getColor(R.color.surface_1), target.surface_1);
        map.put(res.getColor(R.color.subtle), target.subtle);
        map.put(res.getColor(R.color.disabled), target.disabled);
        map.put(res.getColor(R.color.border), target.border);
        map.put(res.getColor(R.color.accent), target.accent);
        map.put(res.getColor(R.color.accent_2), target.accent_2);
        map.put(res.getColor(R.color.accent_3), target.accent_3);
        map.put(res.getColor(R.color.accent_4), target.accent_4);
        map.put(res.getColor(R.color.accent_5), target.accent_5);
        map.put(res.getColor(R.color.success), target.success);
        map.put(res.getColor(R.color.warning), target.warning);
        map.put(res.getColor(R.color.error), target.error);
        map.put(res.getColor(R.color.info), target.info);
        map.put(res.getColor(R.color.link), target.link);

        return map;
    }
}
